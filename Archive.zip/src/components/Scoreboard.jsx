import React from 'react';

const Scoreboard = ({ gameState, matchConfig }) => {
    const { teams, currentInnings, target, matchStatus, winner } = gameState;
    const teamA = teams.A;
    const teamB = teams.B;

    return (
        <div className="scoreboard">
            <div className="match-status">
                {matchStatus === 'COMPLETED' ? (
                    <div className="winner-banner">{winner === 'Draw' ? 'MATCH DRAWN' : `${winner} WINS!`}</div>
                ) : (
                    <div className="innings-indicator">
                        {currentInnings === 'A' ? "1st Innings" : "2nd Innings - Chase"}
                    </div>
                )}
            </div>

            <div className="teams-container">
                {/* Team A */}
                <div className={`team-score ${currentInnings === 'A' ? 'active' : ''}`}>
                    <div className="team-name">{matchConfig?.teamA?.flag} {matchConfig?.teamA?.name || "Team A"}</div>
                    <div className="team-stats">
                        <span className="sc-score">{teamA.score}/{teamA.wickets}</span>
                        <span className="sc-overs">({teamA.overs})</span>
                    </div>
                </div>

                <div className="vs-divider">VS</div>

                {/* Team B */}
                <div className={`team-score ${currentInnings === 'B' ? 'active' : ''}`}>
                    <div className="team-name">{matchConfig?.teamB?.flag} {matchConfig?.teamB?.name || "Team B"}</div>
                    <div className="team-stats">
                        <span className="sc-score">{teamB.score}/{teamB.wickets}</span>
                        <span className="sc-overs">({teamB.overs})</span>
                    </div>
                </div>
            </div>

            {target && matchStatus !== 'COMPLETED' && (
                <div className="target-banner">
                    Target: {target + 1} ({target + 1 - teamB.score} runs needed)
                </div>
            )}
        </div>
    );
};

export default Scoreboard;
